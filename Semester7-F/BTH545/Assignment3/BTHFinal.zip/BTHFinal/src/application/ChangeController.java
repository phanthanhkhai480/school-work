package application;

import java.util.ArrayList;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;    

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;


public class ChangeController {
	ArrayList<String> files = new ArrayList<String>(); //Holds file names
	ArrayList<String> temp = new ArrayList<String>(); //Temp array for changed names
	ArrayList<String> modDate = new ArrayList<String>(); //File Modification dates
	ArrayList<String> gpsInfo = new ArrayList<String>();
	
	String fileEditRegex = "([A-Za-z]['.'])";
	
	//Date formatter
	DateTimeFormatter dtf;
	//Local date/time
	LocalDateTime now;
	@FXML
	private TextArea curFileNames;
	@FXML
	private Button qBrowse;
	@FXML
	private Button browse;
	@FXML
	private Button cNameBtn;
	@FXML
	private TextArea newFileNames;
	@FXML 
	private TextField qFileTextField;
	@FXML 
	private TextField FileTextField;
	@FXML
	private RadioButton addNumber;
	@FXML
	private RadioButton addGPS;
	@FXML
	private RadioButton addNewName;
	@FXML
	private RadioButton addModDate;
	@FXML
	private RadioButton addRenameDate;
	@FXML
	private TextField newFileName;

	/*
	 * Handles when the user clicks on the browse button (For purpose of this 
	 * assignment, only works when needed, i.e. for the browse of the file finder)
	 */
	@FXML
	private void qBrowseFiles(ActionEvent event) {
		//Clear the Current file TextArea when button is pressed
		curFileNames.clear();
		//String that gets if the text area for directory is not empty
		String test;
		test = qFileTextField.getText();
		//Handles if the directory is empty
		if (test.length() <= 0) {
			curFileNames.appendText("Default\n");
		}
		//Handles if the directory is the test string for this assignment
		else if(test.contentEquals("~/stuff/files")) {
			for(int i = 0; i < files.size();i++) {
				curFileNames.appendText(files.get(i)+"\n");
				temp.add(files.get(i));
			}
		}
		//Handles other options (dir/file not found)
		else {
			curFileNames.appendText("Directory/File(s) Not Found!\n");
		}
		
	}
	
	@FXML
	private void browseFiles(ActionEvent event) {
		//Clear the Current file TextArea when button is pressed
		//curFileNames.clear();
		//String that gets if the text area for directory is not empty
		String test;
		test = FileTextField.getText();
		//Handles if the directory is empty
		if (test.length() <= 0) {
			curFileNames.appendText("Default\n");
		}
		//Handles if the directory is the test string for this assignment
		else if(test.contentEquals("~/stuff/files")) {
			for(int i = 0; i < files.size();i++) {
				curFileNames.appendText(files.get(i)+"\n");
				temp.add(files.get(i));
			}
		}
		//Handles other options (dir/file not found)
		else {
			curFileNames.appendText("Directory/File(s) Not Found!\n");
		}
		
	}
	
	
	@FXML
	private void changeNames(ActionEvent event) {
		newFileNames.clear();
		int z = getIndex("Testfile.t");
		String t = curFileNames.getText();
		if(t.length() <=0) {
			newFileNames.appendText("No file is loaded");
		}
		clearBtns();
		files.clear();
		for(int i = 0; i < temp.size(); i++) {
			files.add(temp.get(i));
		}
		curFileNames.clear();
		modDate.clear();
		temp.clear();
		for(int i = 0; i < files.size(); i++) {
			curFileNames.appendText(files.get(i)+"\n");
			getTime();
			String date = dtf.format(now);
			modDate.add(date);
		}
	}
	
	/*
	 * Adds numbers to the end of the file name. Will increment each file 
	 * name (file1001, file2002...)
	 */
	@FXML
	private void addNumberClicked() {
		newFileNames.clear();
		String t = curFileNames.getText();
		//Checks if the addNumber button is selected, and if there are files loaded,
		//if not, then "No file is loaded" will be displayed
		if(t.length() <=0 && addNumber.isSelected()) {
			newFileNames.appendText("No file is loaded");
		}
		//Does checks and if a file is loaded and adds numbers to file names
		else if(t.length() > 0 && addNumber.isSelected()) {
			temp.clear();
			for(int i = 0;i<files.size();i++) {
				temp.add("(00" + (i+1) + ")" +files.get(i));
				newFileNames.appendText(temp.get(i)+"\n");
				addModDate.setDisable(true);
				addGPS.setDisable(true);
				addRenameDate.setDisable(true);
				addNewName.setDisable(true);
				
			}
		}
		//When unselected, removes the numbers
		else if(!addNumber.isSelected()) {
			if(t.length() >0) {
				for(int i = 0;i<files.size();i++) {
					newFileNames.appendText(files.get(i)+"\n");
					addModDate.setDisable(false);
					addGPS.setDisable(false);
					addRenameDate.setDisable(false);
					addNewName.setDisable(false);
					temp.clear();
				}
			}
		}
	}
	
	@FXML
	private void addRenameDateClicked() {
		newFileNames.clear();
		String t = curFileNames.getText();
		if(t.length() <=0 && addRenameDate.isSelected()) {
			newFileNames.appendText("No file is loaded");
		}
		else if(t.length() > 0 && addRenameDate.isSelected()) {
			temp.clear();//Updates the actual time
			for(int i = 0;i<files.size();i++) {
				getTime();
				String date = dtf.format(now);
				temp.add("(" + date+")"+files.get(i));
				newFileNames.appendText(temp.get(i)+"\n");

				addModDate.setDisable(true);
				addGPS.setDisable(true);
				addNumber.setDisable(true);
				addNewName.setDisable(true);
			}
		}
		else if(!addRenameDate.isSelected()) {
			if(t.length() >0) {
				for(int i = 0;i<files.size();i++) {
					newFileNames.appendText(files.get(i)+"\n");
					addModDate.setDisable(false);
					addGPS.setDisable(false);
					addNumber.setDisable(false);
					addNewName.setDisable(false);
					temp.clear();
				}
			}
		}
	}
	
	@FXML
	private void addModDateClicked(){
		newFileNames.clear();
		String t = curFileNames.getText();
		if(t.length() <=0 && addModDate.isSelected()) {
			newFileNames.appendText("No file is loaded");
		}
		else if(t.length() > 0 && addModDate.isSelected()) {
			temp.clear();//Updates the actual time
			for(int i = 0;i<files.size();i++) {
				temp.add("("+modDate.get(i)+")"+files.get(i));
				newFileNames.appendText(temp.get(i)+"\n");
				
				addNumber.setDisable(true);
				addGPS.setDisable(true);
				addRenameDate.setDisable(true);
				addNewName.setDisable(true);
			}
		}
		else if(!addModDate.isSelected()) {
			if(t.length() >0) {
				for(int i = 0;i<files.size();i++) {
					newFileNames.appendText(files.get(i)+"\n");
					addNumber.setDisable(false);
					addGPS.setDisable(false);
					addRenameDate.setDisable(false);
					addNewName.setDisable(false);
					temp.clear();
				}
			}
		}
	}
	
	@FXML
	private void addGPSClicked() {
		newFileNames.clear();
		String t = curFileNames.getText();
		if(t.length() <=0 && addGPS.isSelected()) {
			newFileNames.appendText("No file is loaded");
		}
		else if(t.length() > 0 && addGPS.isSelected()) {
			temp.clear();//Updates the actual time
			for(int i = 0;i<files.size();i++) {
				temp.add(gpsInfo.get(i)+files.get(i));
				newFileNames.appendText(temp.get(i)+"\n");
				
				addModDate.setDisable(true);
				addNumber.setDisable(true);
				addRenameDate.setDisable(true);
				addNewName.setDisable(true);
			}
		}
		else if(!addGPS.isSelected()) {
			if(t.length() >0) {
				for(int i = 0;i<files.size();i++) {
					newFileNames.appendText(files.get(i)+"\n");
					addModDate.setDisable(false);
					addNumber.setDisable(false);
					addRenameDate.setDisable(false);
					addNewName.setDisable(false);
					temp.clear();
				}
			}
		}
	}
	
	private void clearBtns() {
		if(addGPS.isDisabled()) {
			addGPS.setDisable(false);
		}
		if(addModDate.isDisabled()) {
			addModDate.setDisable(false);
		}
		if(addRenameDate.isDisabled()) {
			addRenameDate.setDisable(false);
		}
		if(addNumber.isDisabled()) {
			addNumber.setDisable(false);
		}
		if(newFileName.isDisabled()) {
			newFileName.setDisable(false);
		}
		if(addNewName.isDisabled()) {
			addNewName.setDisable(false);
		}
		if(addGPS.isSelected()) {
			addGPS.setSelected(false);
		}
		if(addNumber.isSelected()) {
			addNumber.setSelected(false);
		}
		if(addModDate.isSelected()) {
			addModDate.setSelected(false);
		}
		if(addRenameDate.isSelected()) {
			addRenameDate.setSelected(false);
		}
		if(addNewName.isSelected()) {
			addNewName.setSelected(false);
		}
	}
	
	//newFileName
	@FXML
	public void addNewNameBtn() {
		
		newFileNames.clear();
		String t = curFileNames.getText();
		if(t.length() <=0 && addNewName.isSelected()) {
			newFileNames.appendText("No file is loaded");
		}
		else if(t.length() > 0 && addNewName.isSelected()) {
			newFileName.setDisable(false);
				addGPS.setDisable(true);
				addModDate.setDisable(true);
				addNumber.setDisable(true);
				addRenameDate.setDisable(true);
		}
		else if(!addNewName.isSelected()) {
			if(t.length() >0) {
				for(int i = 0;i<files.size();i++) {
					newFileNames.appendText(files.get(i)+"\n");
					addModDate.setDisable(false);
					addNumber.setDisable(false);
					addRenameDate.setDisable(false);
					addGPS.setDisable(false);
					newFileName.setDisable(true);
					newFileName.setText("");
					temp.clear();
				}
			}
		}
	}
	
	@FXML
	public void updateFileName() {
		int s = files.size();
		String u = "";
		temp.clear();
		newFileNames.clear();
		String text = newFileName.getText();
		for(int i = 0; i < s; i++) {
			u = files.get(i).substring(files.get(i).lastIndexOf('.') + 1);
			temp.add("(00"+ (i+1) +")" + text +"."+ u);
			newFileNames.appendText(temp.get(i) + "\n");
		}
	}
	
	//Function to get local time
	private void getTime() {
		dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd-HH:mm");  
		now = LocalDateTime.now();  
	}
	
	private int getIndex(String g) {
		for (int i = 0; i < g.length();i++) {
			if(g.charAt(i)=='.') {
				return i;
			}
		}
		return g.length();
	}
	
	
	//Initialization
	@FXML
    public void initialize() {
        //Initialize the files array
		files.add("Games.txt");
		files.add("Finances.txt");
		files.add("GymResults.txt");
		files.add("DONTOPEN.exe");
		files.add("MetalCore_Lyrics_2019.docx");
		
		//Initialize the Modification date array
		modDate.add("2019/11/22-17:43");
		modDate.add("2019/11/15-10:29");
		modDate.add("2018/01/06-20:14");
		modDate.add("1945/07/07-05:29");
		modDate.add("2019/06/30-22:53");
		
		gpsInfo.add("(L-56.13 N / L-106.55 W / C - Canada)");
		gpsInfo.add("(L-23.63 N / L-102.55 W / C - Mexico)");
		gpsInfo.add("(L-37.95 N / L-95.71 W / C - US)");
		gpsInfo.add("(L-35.86 N / L-104.20 W / C - China)");
		gpsInfo.add("(L-39.39 N / L-8.22 W / C - Portugal)");
		
    }

}
