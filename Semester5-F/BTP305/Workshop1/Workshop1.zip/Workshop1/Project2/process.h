#ifndef PROCESS_H
#define PROCESS_H

#include "CString.h"
#include <fstream>

	void process(char* tmpcharacter, std::ostream& out);

#endif
