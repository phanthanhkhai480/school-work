var searchData=
[
  ['task',['Task',['../class_task.html#a43834b15cba574ccd4f25af665649776',1,'Task::Task(std::string &amp;)'],['../class_task.html#a60073fae7e07b8d1721b1bc73adcc6c8',1,'Task::Task(Task &amp;)=delete'],['../class_task.html#ae146c98551f244f62b93bc7b4e334580',1,'Task::Task(Task &amp;&amp;)=delete']]]
];
