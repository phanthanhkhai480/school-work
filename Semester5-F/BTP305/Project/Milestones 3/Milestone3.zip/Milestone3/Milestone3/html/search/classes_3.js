var searchData=
[
  ['task',['Task',['../class_task.html',1,'']]]
];
