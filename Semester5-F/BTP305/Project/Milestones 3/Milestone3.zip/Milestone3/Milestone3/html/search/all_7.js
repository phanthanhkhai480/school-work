var searchData=
[
  ['movetask',['MoveTask',['../class_task.html#ad5f00535195117634b86714e628abd77',1,'Task']]]
];
