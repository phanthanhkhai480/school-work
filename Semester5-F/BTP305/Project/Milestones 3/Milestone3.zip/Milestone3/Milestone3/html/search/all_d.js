var searchData=
[
  ['validate',['Validate',['../class_task.html#ad94a831f3fd8c66b41a1dd24f751cbb1',1,'Task']]]
];
