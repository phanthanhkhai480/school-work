var searchData=
[
  ['operator_2b_3d',['operator+=',['../class_task.html#a3ed2681da2f886dc5742dc180f03a3b8',1,'Task']]],
  ['operator_3d',['operator=',['../class_customer_order.html#a1a83b197a0ca27da950b7321273c46a5',1,'CustomerOrder::operator=(CustomerOrder &amp;)=delete'],['../class_customer_order.html#a87630720d86454abf4b6c66983415e76',1,'CustomerOrder::operator=(CustomerOrder &amp;&amp;abc)'],['../class_task.html#a95c7171fb2f939f1e4ae9a82f1c7c32d',1,'Task::operator=(Task &amp;)=delete'],['../class_task.html#ada7e932e1a40e87069806c264ca3b2c5',1,'Task::operator=(Task &amp;&amp;)=delete']]]
];
