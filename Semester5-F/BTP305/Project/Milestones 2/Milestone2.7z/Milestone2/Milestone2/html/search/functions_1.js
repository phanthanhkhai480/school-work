var searchData=
[
  ['display',['display',['../class_item.html#a41852668dc58d933f786007835dbd8b5',1,'Item::display()'],['../class_customer_order.html#a33b5c9caa32e0100d459ddf4e453e14b',1,'CustomerOrder::Display()']]]
];
