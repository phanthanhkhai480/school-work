var searchData=
[
  ['updatequantity',['updateQuantity',['../class_item.html#ae54aa11885082b7f5e37a925dace0c65',1,'Item']]],
  ['utilities',['Utilities',['../class_utilities.html#ab1676c9ce35cf347a73d16f1094e1271',1,'Utilities']]]
];
