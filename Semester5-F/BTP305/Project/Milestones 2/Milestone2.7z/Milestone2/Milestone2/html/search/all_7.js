var searchData=
[
  ['operator_3d',['operator=',['../class_customer_order.html#a1a83b197a0ca27da950b7321273c46a5',1,'CustomerOrder::operator=(CustomerOrder &amp;)=delete'],['../class_customer_order.html#a87630720d86454abf4b6c66983415e76',1,'CustomerOrder::operator=(CustomerOrder &amp;&amp;abc)']]]
];
