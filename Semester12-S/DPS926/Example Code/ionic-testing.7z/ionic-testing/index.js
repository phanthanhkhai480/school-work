const quantity1 = document.querySelector('#qtt-1');
const quantity2 = document.querySelector('#qtt-2');
const quantity3 = document.querySelector('#qtt-3');
const quantity4 = document.querySelector('#qtt-4');
const quantity5 = document.querySelector('#qtt-5');
const quantity6 = document.querySelector('#qtt-6');
const quantity7 = document.querySelector('#qtt-7');
const quantity8 = document.querySelector('#qtt-8');
const quantity9 = document.querySelector('#qtt-9');
const quantity0 = document.querySelector('#qtt-0');
const quantityAdd = document.querySelector('#qtt-add');
const quantityReset = document.querySelector('#qtt-reset');
const mQuantity = document.querySelector('#quantity');

const mTopping = document.querySelector('#topping');
const mSize = document.querySelector('#size');

let selectedQuantity = 0;
let totalQuantity = 0;

const topping = ["Vegatable", "Meat Balls", "Pepperoni", "Mushroom", "Sausage", "Extra Cheese", "Green Peppers"];
const size = ["Small", "Medium", "Large", "X-Large", "Party"];


quantity0.addEventListener('click', ()=> {  
    selectedQuantity = 0;
    mQuantity.textContent = selectedQuantity;  
})

quantity1.addEventListener('click', ()=> {
    selectedQuantity = 1;
    mQuantity.textContent = selectedQuantity;
})

quantity2.addEventListener('click', ()=> {
    selectedQuantity = 2;
    mQuantity.textContent = selectedQuantity;
})

quantity3.addEventListener('click', ()=> {
    selectedQuantity = 3;
    mQuantity.textContent = selectedQuantity;
})

quantity4.addEventListener('click', ()=> {
    selectedQuantity = 4;
    mQuantity.textContent = selectedQuantity;
})

quantity5.addEventListener('click', ()=> {
    selectedQuantity = 5;
    mQuantity.textContent = selectedQuantity;
})

quantity6.addEventListener('click', ()=> {
    selectedQuantity = 6;
    mQuantity.textContent = selectedQuantity;
})

quantity7.addEventListener('click', ()=> {
    selectedQuantity = 7;
    mQuantity.textContent = selectedQuantity;
})

quantity8.addEventListener('click', ()=> {
    selectedQuantity = 8;
    mQuantity.textContent = selectedQuantity;
})

quantity9.addEventListener('click', ()=> {
    selectedQuantity = 9;
    mQuantity.textContent = selectedQuantity;
})

quantityReset.addEventListener('click', ()=> {    
    selectedQuantity = 'none';
    mQuantity.textContent = selectedQuantity;  
})

quantityAdd.addEventListener('click', ()=> {    totalQuantity += selectedQuantity;  })


for(let a = 0; a < topping.length; a++){
    const newTopping = document.createElement('ion-item');
    newTopping.textContent = topping[a];
    mTopping.appendChild(newTopping);
}

for(let a = 0; a < size.length; a++){
    const newSize = document.createElement('ion-item');
    newSize.textContent = size[a];
    mSize.appendChild(newSize);
}