export class Pizza{
    size_ : string;
    topping_ : string;
}