(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-to-d-add-to-d-module"],{

/***/ "a1Z8":
/*!*******************************************!*\
  !*** ./src/app/add-to-d/add-to-d.page.ts ***!
  \*******************************************/
/*! exports provided: AddToDPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddToDPage", function() { return AddToDPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_add_to_d_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./add-to-d.page.html */ "fj4q");
/* harmony import */ var _add_to_d_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./add-to-d.page.scss */ "thpR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../storage.service */ "qkCY");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");






let AddToDPage = class AddToDPage {
    constructor(storageService, router) {
        this.storageService = storageService;
        this.router = router;
    }
    ngOnInit() {
    }
    onSubmit(form) {
        console.log(form);
        if (form.valid) {
            this.storageService.SaveNewTask(this.date, this.task);
            this.router.navigate(['/home']);
        }
    }
};
AddToDPage.ctorParameters = () => [
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
];
AddToDPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-add-to-d',
        template: _raw_loader_add_to_d_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_add_to_d_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AddToDPage);



/***/ }),

/***/ "fj4q":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/add-to-d/add-to-d.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons>\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>add New ToDo</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form #taskform=\"ngForm\" (ngSubmit)=\"onSubmit(taskform)\">\n<ion-grid>\n  <ion-row>\n    <ion-col>\n      <ion-label position=\"floating\"> Task </ion-label>\n      <ion-input\n      ngModel\n      required\n      minlength = \"3\"\n      name=\"task\"\n      #taskCtrl=\"ngModel\"\n      [(ngModel)]=\"task\"\n      >\n\n      </ion-input>\n    </ion-col>\n    <ion-col>\n      <ion-label position=\"floating\"> Date </ion-label>\n      <ion-datetime min=\"2021-04-06\" max=\"2024-04-06\"\n      ngModel\n      required\n      name=\"date\"\n      #dateCtrl=\"ngModel\"\n      [(ngModel)]=\"date\"\n  >\n\n      </ion-datetime>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col>\n      <ion-button type=\"submit\" submit expand=\"full\" > Save </ion-button>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n</form>\n</ion-content>\n");

/***/ }),

/***/ "sHWc":
/*!*********************************************!*\
  !*** ./src/app/add-to-d/add-to-d.module.ts ***!
  \*********************************************/
/*! exports provided: AddToDPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddToDPageModule", function() { return AddToDPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _add_to_d_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./add-to-d-routing.module */ "xZUF");
/* harmony import */ var _add_to_d_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-to-d.page */ "a1Z8");







let AddToDPageModule = class AddToDPageModule {
};
AddToDPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _add_to_d_routing_module__WEBPACK_IMPORTED_MODULE_5__["AddToDPageRoutingModule"]
        ],
        declarations: [_add_to_d_page__WEBPACK_IMPORTED_MODULE_6__["AddToDPage"]]
    })
], AddToDPageModule);



/***/ }),

/***/ "thpR":
/*!*********************************************!*\
  !*** ./src/app/add-to-d/add-to-d.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhZGQtdG8tZC5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "xZUF":
/*!*****************************************************!*\
  !*** ./src/app/add-to-d/add-to-d-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: AddToDPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddToDPageRoutingModule", function() { return AddToDPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _add_to_d_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./add-to-d.page */ "a1Z8");




const routes = [
    {
        path: '',
        component: _add_to_d_page__WEBPACK_IMPORTED_MODULE_3__["AddToDPage"]
    }
];
let AddToDPageRoutingModule = class AddToDPageRoutingModule {
};
AddToDPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AddToDPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=add-to-d-add-to-d-module.js.map