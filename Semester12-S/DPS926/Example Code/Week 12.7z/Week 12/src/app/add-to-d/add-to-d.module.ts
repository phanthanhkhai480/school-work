import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddToDPageRoutingModule } from './add-to-d-routing.module';

import { AddToDPage } from './add-to-d.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AddToDPageRoutingModule
  ],
  declarations: [AddToDPage]
})
export class AddToDPageModule {}
