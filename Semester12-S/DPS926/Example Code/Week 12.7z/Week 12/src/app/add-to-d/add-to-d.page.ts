import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { StorageService } from '../storage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-to-d',
  templateUrl: './add-to-d.page.html',
  styleUrls: ['./add-to-d.page.scss'],
})
export class AddToDPage implements OnInit {

   task: string
   date : string

  constructor(private storageService: StorageService, private router:Router) { }

  ngOnInit() {
  }


  onSubmit(form:NgForm){

    console.log(form)
    if (form.valid){
      this.storageService.SaveNewTask(this.date,this.task);
      this.router.navigate(['/home']);
    }
  }
}
