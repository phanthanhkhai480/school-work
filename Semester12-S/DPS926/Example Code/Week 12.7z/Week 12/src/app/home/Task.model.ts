export class Task {
  task: string;
  date : string;
  constructor(t : string, d: string){
    this.task = t;
    this.date = d;
  }

}
