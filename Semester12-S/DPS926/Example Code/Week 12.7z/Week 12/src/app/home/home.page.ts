import { Component } from '@angular/core';
import { StorageService } from '../storage.service';
import { AlertController } from '@ionic/angular';
import { Task } from './Task.model';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  Tasks : Task[];

  constructor(private storgeService: StorageService, private alertController: AlertController) {}

  ngOnInit(){
   this.Tasks = this.storgeService.getAllTasks();
  }

  ionViewWillEnter(){
    this.Tasks = this.storgeService.getAllTasks();
  }

  deleteAll(){

    this.alertController.create({
      header: 'Danger!!!',
      message : 'Are sure you want to delete ALL TASKS?? ',
      buttons: [{
        text :'delete',
        handler : ()=>{
          this.storgeService.deleteAllTasks();
          this.Tasks = this.storgeService.getAllTasks();
        }
      },'Cancel']

    }).then(alert => {
      alert.present();
    })
  }

  deleteTask(taskToDelete: Task){

    this.alertController.create({
      header: 'Danger!!!',
      message : 'Are sure you want to delete?? ',
      buttons: [{
        text :'delete',
        handler : ()=>{
          this.storgeService.deleteOneTask(taskToDelete);
          this.Tasks = this.storgeService.getAllTasks();
        }
      },'Cancel']

    }).then(alert => {
      alert.present();
    })

  }

}
