import { Injectable } from '@angular/core';
import { Task } from './home/Task.model';
import { Storage } from '@ionic/storage-angular';

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  private _storage: Storage | null = null;

  constructor(private storage: Storage) {
    this.init();
  }

  async init() {
    // If using, define drivers here: await this.storage.defineDriver(/*...*/);
    const storage = await this.storage.create();
    this._storage = storage;
  }


  // key is the date of the task
  //value is the task description
  public SaveNewTask(key: string, value: any) {
    var newTask = new Task(value,key);
    this._storage?.set(key, newTask);
    this.logAllTasks();
  }

  private logAllTasks(){
    console.log("All Tasks : ");
    this._storage.forEach((key, value, index) => {
      console.log(key, value, index);
    });
  }

  public getAllTasks(){
    var alltasks: Task[] = [];
    if (this._storage != null){
    this._storage.forEach((value, key, index) => {
      alltasks.push(value as Task);
    });
  }
    return alltasks;
  }

  public async deleteAllTasks(){
    await this._storage.clear();
    this.logAllTasks();
  }

  public async deleteOneTask(task: Task){
    await this._storage.remove(task.date);
  }
}
