package com.example.assignment3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class DetailActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    //TextView textView;
    Spinner mSport;
    ImageView image;
    EditText mCity, mName, mMVP;
    Button mSubmit, mUpdate, mDelete, mExit, mUpload;
    LinearLayout topLayout, bottomLayout;
    int m_sport;

    String m_City = "", m_Name = "", m_Sport = "", m_Mvp = "", layout = "";
    int integer = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        mCity = findViewById(R.id.city);
        mName= findViewById(R.id.name);
        mMVP = findViewById(R.id.mvp);
        image = findViewById(R.id.image);
        topLayout = findViewById(R.id.topLayout);
        bottomLayout = findViewById(R.id.bottomLayout);

        //Spinner object
        mSport = (Spinner) findViewById(R.id.sport);
        mSport.setOnItemSelectedListener(this);
        List<String> sport = new ArrayList<String>();
        sport.add("");
        sport.add("Baseball");
        sport.add("Basketball");
        sport.add("Football");
        sport.add("Hockey");
        sport.add("Soccer");
        // Creating adapter for spinner
        final ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>
                (this, R.layout.spinner_item, sport);
        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        mSport.setAdapter(dataAdapter);
        mSport.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                m_sport = mSport.getSelectedItemPosition();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {            }
        });

        mUpload = findViewById(R.id.upload);
        mUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent intent = new Intent("android.media")
            }
        });

        mSubmit = findViewById(R.id.submit);
        mSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseHandler databaseHandler2 = new DatabaseHandler(getApplicationContext());
                String item0 = mCity.getText().toString();
                String item1 = mName.getText().toString();
                String item2 = String.valueOf(m_sport);
                String item3 = mMVP.getText().toString();
                if(item0.length() != 0 && item1.length() != 0) {
                    databaseHandler2.insertItem(item0,item1,item2,item3);
                    mCity.setText("");
                    mName.setText("");
                    mSport.setSelection(0);
                    mMVP.setText("");
                } else
                    Toast.makeText(DetailActivity.this, "Incompleted!", Toast.LENGTH_SHORT).show();
            }
        });

        mUpdate = findViewById(R.id.update);
        mUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(DetailActivity.this);
                builder.setTitle("***Delete Confirm***");
                builder.setMessage("Are you sure you want to delete?\n");
                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(DetailActivity.this, "Update Canceled!", Toast.LENGTH_SHORT).show();
                    }
                });

                builder.setNeutralButton("CLOSE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) { }
                });
                builder.show().getWindow().setLayout(1250  , WindowManager.LayoutParams.WRAP_CONTENT);

            }
        });

        mDelete = findViewById(R.id.delete);
        mDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(DetailActivity.this);
                builder.setTitle("***Delete Confirm***");
                builder.setMessage("Are you sure you want to delete?\n");
                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        DatabaseHandler databaseHandler = new DatabaseHandler(getApplicationContext());
                        Integer test = databaseHandler.deleteItem(m_Name);

                        if(test > 0)
                            Toast.makeText(DetailActivity.this, "Delete Successfully!", Toast.LENGTH_SHORT).show();
                        else
                            Toast.makeText(DetailActivity.this, "Unable to Delete!", Toast.LENGTH_SHORT).show();
                        /*

                        databaseHandler.deleteItem(m_Name);
                        Toast.makeText(DetailActivity.this, "Delete Successfully!", Toast.LENGTH_SHORT).show();

                         */

                        Intent intent = new Intent(DetailActivity.this, MainActivity.class);
                        startActivity(intent);
                    }
                });

                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(DetailActivity.this, "Delete Canceled!", Toast.LENGTH_SHORT).show();
                    }
                });

                builder.setNeutralButton("CLOSE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) { }
                });
                builder.show().getWindow().setLayout(1250  , WindowManager.LayoutParams.WRAP_CONTENT);
            }
        });

        mExit = findViewById(R.id.exit);
        mExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        //fetching information from MainActivity
        Intent intent = getIntent();


        m_City = intent.getStringExtra("city");
        mCity.setText(m_City);

        m_Name = intent.getStringExtra("name");
        mName.setText(m_Name);

        m_Sport = intent.getStringExtra("sport");
        if(!m_Sport.equals(""))
            integer = Integer.parseInt(m_Sport);
        if(integer != 0)
            mSport.setSelection(integer);
        else
            mSport.setSelection(0);

        m_Mvp = intent.getStringExtra("mvp");
        mMVP.setText(m_Mvp);

        layout = intent.getStringExtra("command");
        if(!layout.equals("")) {
            if(layout.equals("add")) {
                mDelete.setVisibility(View.GONE);
                mUpdate.setVisibility(View.GONE);
                mSubmit.setVisibility(View.VISIBLE);
                topLayout.setBackgroundColor(getResources().getColor(android.R.color.holo_orange_light));
                bottomLayout.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
            }
            if(layout.equals("update")) {
                mDelete.setVisibility(View.VISIBLE);
                mUpdate.setVisibility(View.VISIBLE);
                mSubmit.setVisibility(View.GONE);
                topLayout.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                bottomLayout.setBackgroundColor(getResources().getColor(android.R.color.holo_purple));
            }
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { }

    @Override
    public void onNothingSelected(AdapterView<?> parent) { }
}
