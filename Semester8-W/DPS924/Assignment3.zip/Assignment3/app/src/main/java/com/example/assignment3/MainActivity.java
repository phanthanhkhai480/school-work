package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button addTeam, exit;
    ListView information;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //linearLayout = findViewById(R.id.layoutListViewID);
        DatabaseHandler databaseHandler1 = new DatabaseHandler(getApplicationContext());
        final List<String> m_name = databaseHandler1.getAllItem1();
        final String[] name = m_name.toArray(new String[0]);

        final List<String> m_city = databaseHandler1.getAllItem2();
        final String[] city = m_city.toArray(new String[0]);

        final List<String> m_mvp = databaseHandler1.getAllItem4();
        final String[] mvp = m_mvp.toArray(new String[0]);

        final List<String> m_sport = databaseHandler1.getAllItem3();
        final String[] sport = m_sport.toArray(new String[0]);

        information = findViewById(R.id.information);
        final CustomListAdapter adapter = new CustomListAdapter(this, name, city);
        information.setAdapter(adapter);
        information.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra("command", "update");
                intent.putExtra("name", name[position]);
                intent.putExtra("city", city[position]);
                intent.putExtra("sport", sport[position]);
                intent.putExtra("mvp", mvp[position]);
                startActivity(intent);
            }
        });

        addTeam = findViewById(R.id.addTeam);
        addTeam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra("command", "add");
                intent.putExtra("name", "");
                intent.putExtra("city", "");
                intent.putExtra("sport", "");
                intent.putExtra("mvp", "");
                startActivity(intent);
            }
        });

        exit = findViewById(R.id.exit);
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {   finishAffinity();   }
        });
    }
}

//display information in the home page
class CustomListAdapter extends ArrayAdapter<String> {
    private Activity context;
    private String[] city;
    private String[] name;

    CustomListAdapter(Activity m_context, String[] mCity, String[] mName) {
        super(m_context, R.layout.one_item, mCity);
        context = m_context;
        city = mCity;
        name = mName;
    }

    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.one_item, null, true);
        TextView mCity = rowView.findViewById(R.id.displayCity);
        TextView mTeam = rowView.findViewById(R.id.displayTeam);
        mCity.setText(city[position]);
        mTeam.setText(name[position]);
        return rowView;
    }
}
