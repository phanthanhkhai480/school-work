package com.example.assignment3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper {
    DatabaseHandler(Context context) {
        super(context, "Assignment4", null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db1) {
        db1.execSQL("CREATE TABLE ITEMS_IMAGE (ID INTEGER PRIMARY KEY, " +
                "CITY TEXT, NAME TEXT, SPORT TEXT, MVP TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db2, int oldVersion, int newVersion) {
        db2.execSQL("DROP TABLE IF EXISTS ITEMS_IMAGE");
        onCreate(db2);
    }

    public void insertItem(String mCity, String mName, String mSport, String mMVP) {
        SQLiteDatabase db3 = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("CITY", mCity);
        values.put("NAME", mName);
        values.put("SPORT", mSport);
        values.put("MVP", mMVP);
        db3.insert("ITEMS_IMAGE", null, values);
        db3.close();
    }
    public Integer deleteItem(String mName) {
        System.out.println(mName);
        SQLiteDatabase db3 = this.getWritableDatabase();
        //db3.execSQL("DELETE FROM ITEMS_IMAGE WHERE NAME='" + mName + "'" );
        return db3.delete("ITEMS_IMAGE", "NAME = ?", new String[] {mName});
    }

    //get list city information
    public List<String> getAllItem1() {
        List<String> listItem1 = new ArrayList<>();
        String selectQuery = "SELECT * FROM ITEMS_IMAGE";
        SQLiteDatabase db4 = this.getReadableDatabase();
        Cursor cursor = db4.rawQuery(selectQuery, null);
        if(cursor.moveToFirst()) {
            do {
                listItem1.add(cursor.getString(1));
            } while(cursor.moveToNext());
        }
        cursor.close();
        db4.close();
        return listItem1;
    }

    //get list name information
    public List<String> getAllItem2() {
        List<String> listItem2 = new ArrayList<>();
        String selectQuery = "SELECT * FROM ITEMS_IMAGE";
        SQLiteDatabase db4 = this.getReadableDatabase();
        Cursor cursor = db4.rawQuery(selectQuery, null);
        if(cursor.moveToFirst()) {
            do {
                listItem2.add(cursor.getString(2));
            } while(cursor.moveToNext());
        }
        cursor.close();
        db4.close();
        return listItem2;
    }

    //get list sport information
    public List<String> getAllItem3() {
        List<String> listItem3 = new ArrayList<>();
        String selectQuery = "SELECT * FROM ITEMS_IMAGE";
        SQLiteDatabase db4 = this.getReadableDatabase();
        Cursor cursor = db4.rawQuery(selectQuery, null);
        if(cursor.moveToFirst()) {
            do {
                listItem3.add(cursor.getString(3));
            } while(cursor.moveToNext());
        }
        cursor.close();
        db4.close();
        return listItem3;
    }

    //get list mvp
    public List<String> getAllItem4() {
        List<String> listItem4 = new ArrayList<>();
        String selectQuery = "SELECT * FROM ITEMS_IMAGE";
        SQLiteDatabase db4 = this.getReadableDatabase();
        Cursor cursor = db4.rawQuery(selectQuery, null);
        if(cursor.moveToFirst()) {
            do {
                listItem4.add(cursor.getString(4));
            } while(cursor.moveToNext());
        }
        cursor.close();
        db4.close();
        return listItem4;
    }
}
