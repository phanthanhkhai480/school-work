package com.example.assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    RadioButton Alpha,Bravo,Charlie, Delta, Echo, Foxtrot;
    RadioGroup radioGroup1, radioGroup2;
    CheckBox Red,Green,Blue;
    Button say_bonjour1,say_bonjour2,colours;
    TextView text_view1, text_view2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Alpha = (RadioButton)findViewById(R.id.Alpha);
        Bravo = (RadioButton)findViewById(R.id.Bravo);
        Charlie = (RadioButton)findViewById(R.id.Charlie);
        Delta = (RadioButton)findViewById(R.id.Delta);
        Echo = (RadioButton)findViewById(R.id.Echo);
        Foxtrot = (RadioButton)findViewById(R.id.Foxtrot);
        say_bonjour1 = (Button)findViewById(R.id.say_bonjour1);
        say_bonjour2 = (Button)findViewById(R.id.say_bonjour2);
        text_view1 = (TextView)findViewById(R.id.text_view1);
        text_view2 = (TextView)findViewById(R.id.text_view2);
        radioGroup1 = (RadioGroup)findViewById(R.id.radioGroup1);
        radioGroup2 = (RadioGroup)findViewById(R.id.radioGroup2);

        Red = (CheckBox)findViewById(R.id.Red);
        Green = (CheckBox)findViewById(R.id.Green);
        Blue = (CheckBox)findViewById(R.id.Blue);
        colours = (Button)findViewById(R.id.colours);

        //set Toast for each of the RadioButton on the left
        radioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.Alpha)
                    Toast.makeText(getApplicationContext(),"Alpha", Toast.LENGTH_SHORT).show();
                if(checkedId == R.id.Bravo)
                    Toast.makeText(getApplicationContext(),"Bravo", Toast.LENGTH_SHORT).show();
                if(checkedId == R.id.Charlie)
                    Toast.makeText(getApplicationContext(),"Charlie", Toast.LENGTH_SHORT).show();
            }
        });

        //set textview_text for RadioButton on the left
        say_bonjour1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int changedRadio = radioGroup1.getCheckedRadioButtonId();
                if(changedRadio == R.id.Alpha)
                    text_view1.setText("Bonjour Alpha");
                else if(changedRadio == R.id.Bravo)
                    text_view1.setText("Bonjour Bravo");
                else if(changedRadio == R.id.Charlie)
                    text_view1.setText("Bonjour Charlie");
            }
        });

        //set Toast for each of the RadioButton on the right
        radioGroup2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.Delta)
                    Toast.makeText(getApplicationContext(),"Delta", Toast.LENGTH_SHORT).show();
                if(checkedId == R.id.Echo)
                    Toast.makeText(getApplicationContext(),"Echo", Toast.LENGTH_SHORT).show();
                if(checkedId == R.id.Foxtrot)
                    Toast.makeText(getApplicationContext(),"Foxtrot", Toast.LENGTH_SHORT).show();
            }
        });

        //set textview_text for RadioButton on the right
        say_bonjour2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int changedRadio = radioGroup2.getCheckedRadioButtonId();
                if(changedRadio == R.id.Delta)
                    text_view2.setText("Hi Delta");
                else if(changedRadio == R.id.Echo)
                    text_view2.setText("Hi Echo");
                else if(changedRadio == R.id.Foxtrot)
                    text_view2.setText("Hi Foxtrot");
            }
        });

        //set Toast for Colour on the botton
        Red.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(((CheckBox)v).isChecked()) Toast.makeText(getApplicationContext(), "Red", Toast.LENGTH_SHORT).show();
            }
        });

        //set Toast for Colour on the botton
        Green.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(((CheckBox)v).isChecked()) Toast.makeText(getApplicationContext(), "Green", Toast.LENGTH_SHORT).show();
            }
        });

        //set Toast for Colour on the botton
        Blue.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(((CheckBox)v).isChecked()) Toast.makeText(getApplicationContext(), "Blue", Toast.LENGTH_SHORT).show();
            }
        });

        //set Toast Combination for Colour on the bottom
        colours.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuffer colors = new StringBuffer();
                if(Red.isChecked()) colors.append("Red");
                if(Green.isChecked()) colors.append("Green");
                if(Blue.isChecked()) colors.append("Blue");
                Toast.makeText(getApplicationContext(),colors,Toast.LENGTH_SHORT).show();
            }
        });



    }
}
