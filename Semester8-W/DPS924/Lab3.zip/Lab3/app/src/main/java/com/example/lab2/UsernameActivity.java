package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class UsernameActivity extends AppCompatActivity {
    TextView usernameDisplay;
    Button home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_username);

        Intent intent = getIntent();
        String m_usernameDisplay = intent.getStringExtra("usernameDisplay");
        usernameDisplay = (TextView)findViewById(R.id.usernameDisplay);
        String temp = getString(R.string.usernameDisplay, m_usernameDisplay);
        usernameDisplay.setText(temp);

        home = (Button)findViewById(R.id.usernameHome);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
