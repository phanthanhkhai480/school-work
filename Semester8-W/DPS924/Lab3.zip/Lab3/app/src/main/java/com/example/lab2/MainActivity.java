package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView m_username, m_password;
    EditText username, password;
    Button b_username, b_password, b_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        m_username = (TextView)findViewById(R.id.textView2);
        m_password = (TextView)findViewById(R.id.textView3);
        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);
        b_username = (Button)findViewById(R.id.b_username);
        b_password = (Button)findViewById(R.id.b_password);
        b_login = (Button)findViewById(R.id.b_login);

        b_username.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, UsernameActivity.class);
                intent.putExtra("usernameDisplay", username.getText().toString());
                startActivity(intent);
            }
        });

        b_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PasswordActivity.class);
                intent.putExtra("passwordDisplay", password.getText().toString());
                startActivity(intent);
            }
        });

        b_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                intent.putExtra("usernameDisplay", username.getText().toString());
                intent.putExtra("passwordDisplay", password.getText().toString());
                startActivity(intent);
            };
        });
    }
}
