package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PasswordActivity extends AppCompatActivity {
    TextView passwordDisplay;
    Button passwordHome;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_username);

        Intent intent = getIntent();
        String m_passwordDisplay = intent.getStringExtra("passwordDisplay");
        passwordDisplay = (TextView)findViewById(R.id.usernameDisplay);
        String temp = getString(R.string.passwordDisplay, m_passwordDisplay);
        passwordDisplay.setText(temp);

        passwordHome = (Button)findViewById(R.id.usernameHome);
        passwordHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
