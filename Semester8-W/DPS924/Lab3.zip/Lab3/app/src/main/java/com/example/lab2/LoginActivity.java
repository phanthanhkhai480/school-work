package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {
    TextView m_usernameDisplay, m_passwordDisplay;
    Button loginHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        Intent intent = getIntent();
        String temp_usernameDisplay = intent.getStringExtra("usernameDisplay");
        m_usernameDisplay = (TextView)findViewById(R.id.m_usernameDisplay);
        String username = getString(R.string.usernameDisplay, temp_usernameDisplay);
        m_usernameDisplay.setText(username);

        String temp_passwordDisplay = intent.getStringExtra("passwordDisplay");
        m_passwordDisplay = (TextView)findViewById(R.id.m_passwordDisplay);
        String temp = getString(R.string.passwordDisplay, temp_passwordDisplay);
        m_passwordDisplay.setText(temp);

        loginHome = (Button)findViewById(R.id.loginHome);
        loginHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
