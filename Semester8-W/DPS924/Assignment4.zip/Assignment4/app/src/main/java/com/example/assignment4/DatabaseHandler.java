package com.example.assignment4;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper {
    DatabaseHandler(Context context) {
        super(context, "Assignment4", null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db1) {
        //db1.execSQL("DELETE FROM ITEMS_IMAGE");
        db1.execSQL("CREATE TABLE ITEMS_IMAGE (ID INTEGER PRIMARY KEY, " +
                "CITY TEXT, NAME TEXT, SPORT TEXT, MVP TEXT, IMAGE BLOB)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db2, int oldVersion, int newVersion) {
        db2.execSQL("DROP TABLE IF EXISTS ITEMS_IMAGE");
        onCreate(db2);
    }

    void insertItem(String mCity, String mName, String mSport, String mMVP, String image) {
        SQLiteDatabase db3 = this.getWritableDatabase();
        try {
            System.out.println(image);
            FileInputStream fs = new FileInputStream(image);
            byte[] imgByte = new byte[fs.available()];
            fs.read(imgByte);
            ContentValues values = new ContentValues();
            values.put("CITY", mCity);
            values.put("NAME", mName);
            values.put("SPORT", mSport);
            values.put("MVP", mMVP);
            values.put("IMAGE", imgByte);
            db3.insert("ITEMS_IMAGE", null, values);
            fs.close();
            db3.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void deleteItem(int mID) {
        SQLiteDatabase db3 = this.getWritableDatabase();
        db3.delete("ITEMS_IMAGE", "ID = ?", new String[] {String.valueOf(mID)});
    }

    void updateItem(int mID, String mCity, String mName, String mSport, String mMVP, String image ) {
        SQLiteDatabase db3 = this.getWritableDatabase();
        try {
            System.out.println(image);
            FileInputStream fs = new FileInputStream(image);
            byte[] imgByte = new byte[fs.available()];
            fs.read(imgByte);
            ContentValues values = new ContentValues();
            values.put("CITY", mCity);
            values.put("NAME", mName);
            values.put("SPORT", mSport);
            values.put("MVP", mMVP);
            values.put("IMAGE", imgByte);
            db3.update("ITEMS_IMAGE", values, "ID="+mID, null);
            fs.close();
            db3.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    Bitmap loadImage(int position) {
        Bitmap bmp = null;
        String selectQuery = "SELECT * FROM ITEMS_IMAGE WHERE ID="+position;
        SQLiteDatabase db4 = this.getReadableDatabase();
        Cursor cursor = db4.rawQuery(selectQuery, null);
        if(cursor.moveToNext()) {
            byte[] img = cursor.getBlob(5);
            bmp= BitmapFactory.decodeByteArray(img, 0 , img.length);
        }
        cursor.close();
        db4.close();
        return bmp;
    }

    //get list ID information
    List<Integer> getAllItem0() {
        List<Integer> listItem1 = new ArrayList<>();
        String selectQuery = "SELECT * FROM ITEMS_IMAGE";
        SQLiteDatabase db4 = this.getReadableDatabase();
        Cursor cursor = db4.rawQuery(selectQuery, null);
        if(cursor.moveToFirst()) {
            do {
                listItem1.add(cursor.getInt(0));
            } while(cursor.moveToNext());
        }
        cursor.close();
        db4.close();
        return listItem1;
    }

    //get list city information
    List<String> getAllItem1() {
        List<String> listItem1 = new ArrayList<>();
        String selectQuery = "SELECT * FROM ITEMS_IMAGE";
        SQLiteDatabase db4 = this.getReadableDatabase();
        Cursor cursor = db4.rawQuery(selectQuery, null);
        if(cursor.moveToFirst()) {
            do {
                listItem1.add(cursor.getString(1));
            } while(cursor.moveToNext());
        }
        cursor.close();
        db4.close();
        return listItem1;
    }

    //get list name information
    List<String> getAllItem2() {
        List<String> listItem2 = new ArrayList<>();
        String selectQuery = "SELECT * FROM ITEMS_IMAGE";
        SQLiteDatabase db4 = this.getReadableDatabase();
        Cursor cursor = db4.rawQuery(selectQuery, null);
        if(cursor.moveToFirst()) {
            do {
                listItem2.add(cursor.getString(2));
            } while(cursor.moveToNext());
        }
        cursor.close();
        db4.close();
        return listItem2;
    }

    //get list sport information
    List<String> getAllItem3() {
        List<String> listItem3 = new ArrayList<>();
        String selectQuery = "SELECT * FROM ITEMS_IMAGE";
        SQLiteDatabase db4 = this.getReadableDatabase();
        Cursor cursor = db4.rawQuery(selectQuery, null);
        if(cursor.moveToFirst()) {
            do {
                listItem3.add(cursor.getString(3));
            } while(cursor.moveToNext());
        }
        cursor.close();
        db4.close();
        return listItem3;
    }

    //get list mvp
    List<String> getAllItem4() {
        List<String> listItem4 = new ArrayList<>();
        String selectQuery = "SELECT * FROM ITEMS_IMAGE";
        SQLiteDatabase db4 = this.getReadableDatabase();
        Cursor cursor = db4.rawQuery(selectQuery, null);
        if(cursor.moveToFirst()) {
            do {
                listItem4.add(cursor.getString(4));
            } while(cursor.moveToNext());
        }
        cursor.close();
        db4.close();
        return listItem4;
    }
}