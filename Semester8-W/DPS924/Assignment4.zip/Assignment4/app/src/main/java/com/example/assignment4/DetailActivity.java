package com.example.assignment4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DetailActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private static final int WRITE_PERMISSION_CODE = 1;
    private static final int READ_PERMISSION_CODE = 2;
    private static final int PICK_IMAGE_REQUEST = 3;

    Spinner mSport;
    ImageView image;
    EditText mCity, mName, mMVP;
    Button mSubmit, mUpdate, mDelete, mExit, mUpload;
    LinearLayout topLayout, bottomLayout;

    String m_City = "", m_Name = "", m_Sport = "", m_Mvp = "", layout = "", fileLocation ="";
    int integer = 0, m_id = 0, m_sport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        mCity = findViewById(R.id.city);
        mName= findViewById(R.id.name);
        mMVP = findViewById(R.id.mvp);
        image = findViewById(R.id.image);
        topLayout = findViewById(R.id.topLayout);
        bottomLayout = findViewById(R.id.bottomLayout);

        //Spinner object
        mSport = (Spinner) findViewById(R.id.sport);
        mSport.setOnItemSelectedListener(this);
        List<String> sport = new ArrayList<String>();
        sport.add("");
        sport.add("Baseball");
        sport.add("Basketball");
        sport.add("Football");
        sport.add("Hockey");
        sport.add("Soccer");
        // Creating adapter for spinner
        final ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>
                (this, R.layout.spinner_item, sport);
        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        mSport.setAdapter(dataAdapter);
        mSport.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                m_sport = mSport.getSelectedItemPosition();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {            }
        });

        mUpload = findViewById(R.id.upload);
        mUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                readPermissionRequest();
                writePermissionRequest();
                showFileChooser();
                System.out.println("File Location" + fileLocation);
            }
        });

        mSubmit = findViewById(R.id.submit);
        mSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseHandler databaseHandler2 = new DatabaseHandler(getApplicationContext());
                String item0 = mCity.getText().toString();
                String item1 = mName.getText().toString();
                String item2 = String.valueOf(m_sport);
                String item3 = mMVP.getText().toString();
                String item4 = fileLocation;
                if(item0.length() != 0 && item1.length() != 0 && item4.length() != 0) {
                    System.out.println(item4);
                    databaseHandler2.insertItem(item0,item1,item2,item3, item4);
                    mCity.setText("");
                    mName.setText("");
                    mSport.setSelection(0);
                    mMVP.setText("");
                    image.setImageResource(R.drawable.notfound);
                } else
                    Toast.makeText(DetailActivity.this, "Incompleted!", Toast.LENGTH_SHORT).show();
            }
        });

        mUpdate = findViewById(R.id.update);
        mUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(DetailActivity.this);
                builder.setTitle("***Update Confirm***");
                builder.setMessage("Are you sure you want to update?\n");
                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        DatabaseHandler databaseHandler1 = new DatabaseHandler(getApplicationContext());
                        String item0 = mCity.getText().toString();
                        String item1 = mName.getText().toString();
                        String item2 = String.valueOf(m_sport);
                        String item3 = mMVP.getText().toString();
                        String item4 = fileLocation;
                        databaseHandler1.updateItem(m_id, item0, item1, item2, item3, item4);
                        Toast.makeText(DetailActivity.this, "Update Successfully!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(DetailActivity.this, MainActivity.class);
                        startActivity(intent);
                    }
                });

                builder.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(DetailActivity.this, "Update Canceled!", Toast.LENGTH_SHORT).show();
                    }
                });

                builder.show().getWindow().setLayout(1250  , WindowManager.LayoutParams.WRAP_CONTENT);

            }
        });

        mDelete = findViewById(R.id.delete);
        mDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(DetailActivity.this);
                builder.setTitle("***Delete Confirm***");
                builder.setMessage("Are you sure you want to delete?\n");
                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        DatabaseHandler databaseHandler2 = new DatabaseHandler(getApplicationContext());
                        databaseHandler2.deleteItem(m_id);
                        Toast.makeText(DetailActivity.this, "Delete Successfully!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(DetailActivity.this, MainActivity.class);
                        startActivity(intent);
                    }
                });

                builder.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(DetailActivity.this, "Delete Canceled!", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show().getWindow().setLayout(1250  , WindowManager.LayoutParams.WRAP_CONTENT);
            }
        });

        mExit = findViewById(R.id.exit);
        mExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        //fetching information from MainActivity
        Intent intent = getIntent();
        m_id = intent.getIntExtra("ID", -1);

        m_City = intent.getStringExtra("city");
        mCity.setText(m_City);

        m_Name = intent.getStringExtra("name");
        mName.setText(m_Name);

        m_Sport = intent.getStringExtra("sport");
        if(!m_Sport.equals(""))
            integer = Integer.parseInt(m_Sport);
        if(integer != 0)
            mSport.setSelection(integer);
        else
            mSport.setSelection(0);

        m_Mvp = intent.getStringExtra("mvp");
        mMVP.setText(m_Mvp);



        layout = intent.getStringExtra("command");
        if(!layout.equals("")) {
            if(layout.equals("add")) {
                mDelete.setVisibility(View.GONE);
                mUpdate.setVisibility(View.GONE);
                mSubmit.setVisibility(View.VISIBLE);
                topLayout.setBackgroundColor(getResources().getColor(android.R.color.holo_orange_light));
                bottomLayout.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
                //set image object
                image.setImageResource(R.drawable.notfound);
            }
            if(layout.equals("update")) {
                mDelete.setVisibility(View.VISIBLE);
                mUpdate.setVisibility(View.VISIBLE);
                mSubmit.setVisibility(View.GONE);
                topLayout.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                bottomLayout.setBackgroundColor(getResources().getColor(android.R.color.holo_purple));
                DatabaseHandler databaseHandler = new DatabaseHandler(getApplicationContext());
                Bitmap img = databaseHandler.loadImage(m_id);
                image.setImageBitmap(img);
            }
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { }

    @Override
    public void onNothingSelected(AdapterView<?> parent) { }

    //request to write into storage
    public void writePermissionRequest() {
        if(ContextCompat.checkSelfPermission
                (DetailActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            if(ActivityCompat.shouldShowRequestPermissionRationale
                    (DetailActivity.this,Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                ActivityCompat.requestPermissions(DetailActivity.this,
                        new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, WRITE_PERMISSION_CODE);
            }
            else {
                ActivityCompat.requestPermissions(DetailActivity.this,
                        new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, WRITE_PERMISSION_CODE);
            }
        }
    }

    //request to read into storage
    public void readPermissionRequest() {
        if(ContextCompat.checkSelfPermission
                (DetailActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            if(ActivityCompat.shouldShowRequestPermissionRationale
                    (DetailActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)) {
                ActivityCompat.requestPermissions(DetailActivity.this,
                        new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, READ_PERMISSION_CODE);
            }
            else {
                ActivityCompat.requestPermissions(DetailActivity.this,
                        new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, READ_PERMISSION_CODE);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == WRITE_PERMISSION_CODE || requestCode == READ_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted!", Toast.LENGTH_SHORT).show();
            } else
                Toast.makeText(this, "Permission not Granted!", Toast.LENGTH_SHORT).show();
        }
    }

    private void showFileChooser() {
        if(ContextCompat.checkSelfPermission
                (DetailActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED) {
            if(ContextCompat.checkSelfPermission
                    (DetailActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
            }
        }
    }

   @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK &&
                data != null && data.getData() != null) {
            Uri filePath = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                image.setImageBitmap(bitmap);
                fileLocation = getPath(filePath);
            } catch (IOException ignored) {   }
        }
   }

   public String getPath(Uri path) {
        if(path == null)
            return null;
        else {
            String[] projection = {MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(path, projection, null,null,null);
            if(cursor != null) {
                System.out.println("HERE");
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                cursor.moveToFirst();
                String mPath =  cursor.getString(column_index);
                cursor.close();
                return mPath;
            } else
                return path.getPath();
        }
   }
}
