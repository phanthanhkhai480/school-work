package com.example.lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;


public class second_activity extends AppCompatActivity {
    ListView left,right;
    int size = 0;
    String[] nameLeft = new String[size];
    String[] deptLeft = new String[size];
    String[] yearLeft = new String[size];
    String[] nameRight = new String[size];
    String[] deptRight = new String[size];
    String[] yearRight = new String[size];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_activity);

        Intent intent = getIntent();
        size = intent.getIntExtra("size",0);
        nameLeft = intent.getStringArrayExtra("nameLeft");
        deptLeft = intent.getStringArrayExtra("deptLeft");
        yearLeft = intent.getStringArrayExtra("yearLeft");
        nameRight = intent.getStringArrayExtra("nameRight");
        deptRight = intent.getStringArrayExtra("deptRight");
        yearRight = intent.getStringArrayExtra("yearRight");

        left = findViewById(R.id.layout1);
        ArrayAdapter<String> adapter_left = new ArrayAdapter<>(this, R.layout.view, nameLeft);
        left.setAdapter(adapter_left);
        left.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(second_activity.this, inner_left.class);
                intent.putExtra("m_nameLeft", nameLeft[position]);
                intent.putExtra("m_deptLeft", deptLeft[position]);
                intent.putExtra("m_yearLeft", yearLeft[position]);
                startActivity(intent);
            }
        });

        right = findViewById(R.id.layout2);
        ArrayAdapter<String> adapter_right = new ArrayAdapter<>(this,R.layout.view, nameRight);
        right.setAdapter(adapter_right);
        right.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(second_activity.this, inner_right.class);
                intent.putExtra("m_nameRight", nameRight[position]);
                intent.putExtra("m_deptRight", deptRight[position]);
                intent.putExtra("m_yearRight", yearRight[position]);
                startActivity(intent);
            }
        });
    }
}
