package com.example.lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class inner_left extends AppCompatActivity {
    TextView name, dept, year;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inner_left);

        name = findViewById(R.id.nameL);
        dept = findViewById(R.id.deptL);
        year = findViewById(R.id.yearL);

        Intent intent = getIntent();
        String nameL = intent.getStringExtra("m_nameLeft");
        String deptL = intent.getStringExtra("m_deptLeft");
        String yearL = intent.getStringExtra("m_yearLeft");
        name.setText(nameL);
        dept.setText(deptL);
        year.setText(yearL);
    }
}
