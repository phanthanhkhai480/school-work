package com.example.lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class inner_right extends AppCompatActivity {
    TextView name, dept, year;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inner_right);

        name = findViewById(R.id.nameR);
        dept = findViewById(R.id.deptR);
        year = findViewById(R.id.yearR);

        Intent intent = getIntent();
        String nameR = intent.getStringExtra("m_nameRight");
        String deptR = intent.getStringExtra("m_deptRight");
        String yearR = intent.getStringExtra("m_yearRight");
        name.setText(nameR);
        dept.setText(deptR);
        year.setText(yearR);
    }
}
