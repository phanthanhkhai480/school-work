package com.example.lab7;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    EditText nameLeft, nameRight, deptLeft, deptRight, yearLeft, yearRight;
    Button addLeft, addRight, viewAll;
    SQLiteDatabase sqLiteDatabase;
    int size = 50;
    String[] itemNameLeft = new String[size];
    String[] itemDeptLeft = new String[size];
    String[] itemYearLeft = new String[size];
    String[] itemNameRight = new String[size];
    String[] itemDeptRight = new String[size];
    String[] itemYearRight = new String[size];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameLeft = findViewById(R.id.nameLeft);
        nameRight = findViewById(R.id.nameRight);
        deptLeft = findViewById(R.id.deptLeft);
        deptRight = findViewById(R.id.deptRight);
        yearLeft = findViewById(R.id.yearLeft);
        yearRight = findViewById(R.id.yearRight);

        addLeft = findViewById(R.id.addLeft);
        addRight = findViewById(R.id.addRight);
        viewAll = findViewById(R.id.viewAll);

        for(int a = 0; a < size; a++) {
            itemNameLeft[a] = "";
            itemDeptLeft[a] = "";
            itemYearLeft[a] = "";
            itemNameRight[a] = "";
            itemDeptRight[a] = "";
            itemYearRight[a] = "";
        }

        //CREATE A DATABASE TO STORE TABLE
        sqLiteDatabase = openOrCreateDatabase("DPS924", Context.MODE_PRIVATE, null);
        //CREATE A TABLE TO STORE DATA ON THE LEFT SIDE
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS LAB7_LEFT(NAME VARCHAR, DEPT VARCHAR, YEAR INT);");
        //sqLiteDatabase.execSQL("DELETE FROM LAB7_LEFT");
        //CREATE A TABLE TO STORE DATA ON THE RIGHT SIDE
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS LAB7_RIGHT(NAME VARCHAR, DEPT VARCHAR, YEAR INT);");
        //sqLiteDatabase.execSQL("DELETE FROM LAB7_RIGHT");

        //SET VALUES INTO TABLE ON THE LEFT SIDE
        addLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(nameLeft.getText().toString().equals("") ||
                        deptLeft.getText().toString().equals("") ||
                        yearLeft.getText().toString().equals(""))
                    Toast.makeText(MainActivity.this, "Incomplete", Toast.LENGTH_SHORT).show();
                else {
                    sqLiteDatabase.execSQL("INSERT INTO LAB7_LEFT VALUES('" + nameLeft.getText() + "','" +
                            deptLeft.getText() + "','" + yearLeft.getText() + "');");
                    nameLeft.setText("");
                    deptLeft.setText("");
                    yearLeft.setText("");
                }
            }
        });

        ///SET VALUE INTO TABLE ON THE RIGHT SIDE
        addRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(nameRight.getText().toString().equals("") ||
                        deptRight.getText().toString().equals("") ||
                        yearRight.getText().toString().equals(""))
                        Toast.makeText(MainActivity.this, "Incomplete", Toast.LENGTH_SHORT).show();
                else {
                    sqLiteDatabase.execSQL("INSERT INTO LAB7_RIGHT VALUES('" + nameRight.getText() + "','" +
                            deptRight.getText() + "','" + yearRight.getText() + "');");
                    nameRight.setText("");
                    deptRight.setText("");
                    yearRight.setText("");
                }
            }
        });

        //DISPLAY DATA FROM TABLE
        viewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursorLeft = sqLiteDatabase.rawQuery("SELECT * FROM LAB7_LEFT", null);
                Cursor cursorRight = sqLiteDatabase.rawQuery("SELECT * FROM LAB7_RIGHT", null);
                int counter = 0;
                //TRANSFER DATA FROM TABLE LAB7_LEFT TO LOCAL VARIABLE
                while (cursorLeft.moveToNext()) {
                    itemNameLeft[counter] = cursorLeft.getString(cursorLeft.getColumnIndex("NAME"));
                    itemDeptLeft[counter] = cursorLeft.getString(cursorLeft.getColumnIndex("DEPT"));
                    itemYearLeft[counter] = cursorLeft.getString(cursorLeft.getColumnIndex("YEAR"));
                    counter++;
                }
                counter = 0;
                //TRANSFER DATA FROM TABLE LAB7_LEFT TO LOCAL VARIABLE
                while (cursorRight.moveToNext()) {
                    itemNameRight[counter] = cursorRight.getString(cursorRight.getColumnIndex("NAME"));
                    itemDeptRight[counter] = cursorRight.getString(cursorRight.getColumnIndex("DEPT"));
                    itemYearRight[counter] = cursorRight.getString(cursorRight.getColumnIndex("YEAR"));
                    counter++;
                }
                Intent intent = new Intent(MainActivity.this, second_activity.class);
                intent.putExtra("size", size);
                intent.putExtra("nameLeft", itemNameLeft);
                intent.putExtra("deptLeft", itemDeptLeft);
                intent.putExtra("yearLeft", itemYearLeft);
                intent.putExtra("nameRight", itemNameRight);
                intent.putExtra("deptRight", itemDeptRight);
                intent.putExtra("yearRight", itemYearRight);
                startActivity(intent);
            }
        });

    }
}
