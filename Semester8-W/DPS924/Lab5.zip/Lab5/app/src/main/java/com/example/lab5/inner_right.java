package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class inner_right extends AppCompatActivity {
    TextView capital_name, country_name, letter;
    ImageView flag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inner_right);

        capital_name = (TextView) findViewById(R.id.capital_name);
        country_name = (TextView) findViewById(R.id.country_name);
        letter = (TextView) findViewById(R.id.letter);
        flag = (ImageView) findViewById(R.id.flag);

        Intent intent = getIntent();
        String mFlag = intent.getStringExtra("flag");
        String mCountry = intent.getStringExtra("country");
        String mCapital = intent.getStringExtra("capital");
        String mletter = intent.getStringExtra("letter");
        capital_name.setText(mCapital);
        country_name.setText(mCountry);
        letter.setText(mletter);
        Integer mImage = new Integer(mFlag);
        flag.setImageResource(mImage);
    }
}
