package com.example.lab5;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.ImageView;

import androidx.annotation.NonNull;

class CustomAdapterRight extends ArrayAdapter<String> {
    private Activity mrightContext;
    private String[] mrightCountry;
    private String[] mrightCapital;
    private String[] mrightLetter;
    private Integer[] mrightFlag;

    CustomAdapterRight(Activity mContext, String[] mCountry, Integer[] mFlag,
                       String[] mCapital, String[] mLetter) {
        super(mContext, R.layout.right_side, mCountry);
        this.mrightContext = mContext;    this.mrightCountry = mCountry;
        this.mrightCapital = mCapital;    this.mrightFlag = mFlag;
        this.mrightLetter = mLetter;
    }

    @Override @NonNull
    public View getView(int position, View view, @NonNull ViewGroup parent) {
        LayoutInflater inflater = mrightContext.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.right_side, null, true);

        TextView rightCountry = (TextView) rowView.findViewById(R.id.rightCountry);
        TextView rightCapital = (TextView) rowView.findViewById(R.id.rightCapital);
        TextView rightLetter = (TextView) rowView.findViewById(R.id.rightLetter);
        ImageView rightFlag = (ImageView)rowView.findViewById(R.id.rightFlag);

        rightCapital.setText(mrightCapital[position]);
        rightCountry.setText(mrightCountry[position]);
        rightFlag.setImageResource(mrightFlag[position]);
        rightLetter.setText(mrightLetter[position]);

        return rowView;
    }
}
