package com.example.lab5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    String[] leftCountries = {
            "Argentina", "Bahamas", "Cameroon", "Denmark", "Egypt", "Finland",
            "Georgia", "Honduras", "Indonesia", "Jamaica", "Kenya", "Laos" };
    String[] leftCapitals = {
            "Buenos Aires", "Nassau", "Yaounde", "Copenhagen", "Cairo", "Helsinki",
            "Tbilisi", "Tegucigalpa", "Jakarta", "Kingston", "Nairobi", "Vientiane"   };
    Integer[] flagLeft = {
            R.drawable.argentina, R.drawable.bahamas, R.drawable.cameroon, R.drawable.denmark,
            R.drawable.egypt, R.drawable.finland, R.drawable.georgia, R.drawable.honduras,
            R.drawable.indonesia, R.drawable.jamaica, R.drawable.kenya, R.drawable.laos };

    String[] rightCountries = {
            "Australia", "Bangladesh", "Columbia", "Djibouti", "Ethiopia", "France",
            "Ghana", "Hungary", "Iran", "Japan", "Kuwait", "Lebanon"    };
    String[] rightCapitals = {
            "Canberra", "Dhaka", "Bogota", "Djibouti", "Addis Ababa", "Paris",
            "Accra", "Budapest", "Tehran", "Tokyo", "Kuwait City", "Beirut"     };
    Integer[] flagRight = {
            R.drawable.australia, R.drawable.bangladesh, R.drawable.colombia, R.drawable.djibouti,
            R.drawable.ethiopia, R.drawable.france, R.drawable.ghana, R.drawable.hungary,
            R.drawable.iran, R.drawable.japan, R.drawable.kuwait, R.drawable.lebanon };
    String[] letter = new String[rightCapitals.length];



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listViewLeft = (ListView) findViewById(R.id.layout1);
        CustomAdapterLeft adapterLeft = new CustomAdapterLeft(this, leftCountries, flagLeft, leftCapitals);
        listViewLeft.setAdapter(adapterLeft);
        listViewLeft.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(MainActivity.this, inner_left.class);
                intent.putExtra("country", leftCountries[i]);
                intent.putExtra("capital", leftCapitals[i]);
                intent.putExtra("flag", flagLeft[i].toString());
                startActivity(intent);
            }
        });

        for(int a = 0; a < letter.length; a++)
            letter[a] = (char)(65+a) + "";

        ListView listViewRight = (ListView) findViewById(R.id.layout2);
        CustomAdapterRight adapterRight = new CustomAdapterRight(this,rightCountries, flagRight, rightCapitals, letter);
        listViewRight.setAdapter(adapterRight);
        listViewRight.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(MainActivity.this, inner_right.class);
                intent.putExtra("country", rightCountries[i]);
                intent.putExtra("capital", rightCapitals[i]);
                intent.putExtra("flag", flagRight[i].toString());
                intent.putExtra("letter", letter[i]);
                startActivity(intent);
            }
        });

    }
}


