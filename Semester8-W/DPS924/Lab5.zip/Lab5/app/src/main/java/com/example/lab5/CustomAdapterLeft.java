package com.example.lab5;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.ImageView;

import androidx.annotation.NonNull;

class CustomAdapterLeft extends ArrayAdapter<String> {
    private Activity mleftContext;
    private String[] mleftCountry;
    private String[] mleftCapital;
    private Integer[] mleftFlag;

    CustomAdapterLeft(Activity mContext, String[] mCountry, Integer[] mFlag, String[] mCapital) {
        super(mContext, R.layout.left_side, mCountry);
        this.mleftContext = mContext;    this.mleftCountry = mCountry;
        this.mleftCapital = mCapital;    this.mleftFlag = mFlag;
    }

    @Override @NonNull
    public View getView(int position, View view, @NonNull ViewGroup parent) {
        LayoutInflater inflater = mleftContext.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.left_side, null, true);

        TextView leftCountry = (TextView) rowView.findViewById(R.id.leftCountry);
        TextView leftCapital = (TextView) rowView.findViewById(R.id.leftCapital);
        ImageView leftFlag = (ImageView)rowView.findViewById(R.id.leftFlag);

        leftCapital.setText(mleftCapital[position]);
        leftCountry.setText(mleftCountry[position]);
        leftFlag.setImageResource(mleftFlag [position]);
        return rowView;
    }
}






