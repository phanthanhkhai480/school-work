package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class inner_left extends AppCompatActivity {
    TextView capital_name, country_name;
    ImageView flag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inner_left);

        capital_name = (TextView) findViewById(R.id.capital_name);
        country_name = (TextView) findViewById(R.id.country_name);
        flag = (ImageView) findViewById(R.id.flag);

        Intent intent = getIntent();
        String mFlag = intent.getStringExtra("flag");
        String mCountry = intent.getStringExtra("country");
        String mCapital = intent.getStringExtra("capital");
        capital_name.setText(mCapital);
        country_name.setText(mCountry);
        Integer mImage = new Integer(mFlag);
        flag.setImageResource(mImage);
    }
}
