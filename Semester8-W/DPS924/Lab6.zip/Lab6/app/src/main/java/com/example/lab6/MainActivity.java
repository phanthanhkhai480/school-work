package com.example.lab6;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button add, view, find, delete;
    EditText m_id, m_name, m_marks;
    SQLiteDatabase sqLiteDatabase1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        add = findViewById(R.id.add_new_student);
        view = findViewById(R.id.view_all_student);
        find = findViewById(R.id.find_student_id);
        delete = findViewById(R.id.delete_student_id);
        m_id = findViewById(R.id.id);
        m_name = findViewById(R.id.name);
        m_marks = findViewById(R.id.marks);

        sqLiteDatabase1 = openOrCreateDatabase("DPS924", Context.MODE_PRIVATE, null);
        sqLiteDatabase1.execSQL("CREATE TABLE IF NOT EXISTS LAB6(ID VARCHAR, NAME VARCHAR, MAKRS INT);");

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                StringBuffer stringOfData = new StringBuffer();
                if (m_id.getText().toString().equals("") ||
                        m_name.getText().toString().equals("") ||
                        m_marks.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, "Incomplete", Toast.LENGTH_SHORT).show();
                }
                else {
                    sqLiteDatabase1.execSQL("INSERT INTO LAB6 VALUES('" + m_id.getText() + "'," +
                            "'" + m_name.getText() + "',"  +
                            "'" + m_marks.getText() +"');");

                    alertDialog.setTitle(R.string.title_view);
                    stringOfData.append("ID:" + m_id.getText().toString() + "  ");
                    stringOfData.append("Name:" + m_name.getText().toString() + "  ");
                    stringOfData.append("Marks:" + m_marks.getText().toString() + "\n");
                    alertDialog.setMessage(stringOfData);
                    //Toast.makeText(MainActivity.this, "Added", Toast.LENGTH_SHORT).show();

                    alertDialog.setNeutralButton("CLOSE", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) { }
                    });
                    m_id.setText("");   m_name.setText(""); m_marks.setText("");
                    alertDialog.show().getWindow().setLayout(1250  , WindowManager.LayoutParams.WRAP_CONTENT);
                }
            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                Cursor cursor = sqLiteDatabase1.rawQuery("SELECT * FROM LAB6", null);
                StringBuffer stringOfData = new StringBuffer();
                boolean check = false;

                while(cursor.moveToNext()) {
                    //Toast.makeText(MainActivity.this, "HAS DATA", Toast.LENGTH_SHORT).show();

                    alertDialog.setTitle(R.string.title_view);
                    stringOfData.append("ID:" +
                            cursor.getString(cursor.getColumnIndex("ID")) + "  ");
                    stringOfData.append("Name:" +
                            cursor.getString(cursor.getColumnIndex("NAME")) + "  ");
                    stringOfData.append("Marks:" +
                            cursor.getString(cursor.getColumnIndex("MAKRS")) + "\n");
                    alertDialog.setMessage(stringOfData);

                    check = true;
                }

                if(!check) {
                    //Toast.makeText(MainActivity.this, "NO DATA", Toast.LENGTH_SHORT).show();
                    alertDialog.setTitle(R.string.title_empty);
                }

                alertDialog.setNeutralButton("CLOSE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) { }
                });

                alertDialog.show().getWindow().setLayout(1250  , WindowManager.LayoutParams.WRAP_CONTENT);
                cursor.close();
            }
        });

        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                Cursor cursor = sqLiteDatabase1.rawQuery("SELECT * FROM LAB6", null);
                StringBuffer stringOfData = new StringBuffer();
                boolean check = false;

                while(cursor.moveToNext()) {
                    if(cursor.getString(cursor.getColumnIndex("ID")).equals(m_id.getText().toString())) {
                        //Toast.makeText(MainActivity.this, "HAS CURSOR", Toast.LENGTH_SHORT).show();

                        alertDialog.setTitle(R.string.title_true);
                        stringOfData.append("ID:" +
                                cursor.getString(cursor.getColumnIndex("ID")) + "  ");
                        stringOfData.append("Name:" +
                                cursor.getString(cursor.getColumnIndex("NAME")) + "  ");
                        stringOfData.append("Marks:" +
                                cursor.getString(cursor.getColumnIndex("MAKRS")) + "\n");
                        alertDialog.setMessage(stringOfData);

                        check = true;
                    }
                }

                if(!check) {
                    //Toast.makeText(MainActivity.this, "CHECK FAILED", Toast.LENGTH_SHORT).show();
                    alertDialog.setTitle(R.string.title_false);
                }

                alertDialog.setNeutralButton("CLOSE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) { }
                });

                m_id.setText("");   m_name.setText(""); m_marks.setText("");
                alertDialog.show().getWindow().setLayout(1250  , WindowManager.LayoutParams.WRAP_CONTENT);
                cursor.close();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                Cursor cursor = sqLiteDatabase1.rawQuery("SELECT * FROM LAB6", null);
                boolean check = false;

                while(cursor.moveToNext()) {
                    if(cursor.getString(cursor.getColumnIndex("ID")).equals(m_id.getText().toString())) {
                        //Toast.makeText(MainActivity.this, "HAS CURSOR", Toast.LENGTH_SHORT).show();
                        check = true;
                        alertDialog.setTitle("***Delete Confirm***");
                        alertDialog.setMessage("Are you sure you want to delete this students?\n");
                        alertDialog.setMessage("NOTE: ALL STUDENT WITH ID:" + m_id.getText().toString() + " WILL BE REMOVED!\n");

                        alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                AlertDialog.Builder alertDialogDelete = new AlertDialog.Builder(MainActivity.this);
                                Cursor cursor1 = sqLiteDatabase1.rawQuery("SELECT * FROM LAB6", null);
                                while(cursor1.moveToNext()) {
                                    if(cursor1.getString(cursor1.getColumnIndex("ID"))
                                            .equals(m_id.getText().toString())) {

                                        alertDialogDelete.setTitle(R.string.title_delete);
                                        StringBuffer stringOfData = new StringBuffer();
                                        stringOfData.append("ID:" +
                                                cursor1.getString(cursor1.getColumnIndex("ID")) + "  ");
                                        stringOfData.append("Name:" +
                                                cursor1.getString(cursor1.getColumnIndex("NAME")) + "  ");
                                        stringOfData.append("Marks:" +
                                                cursor1.getString(cursor1.getColumnIndex("MAKRS")) + "\n");
                                        alertDialogDelete.setMessage(stringOfData);
                                        sqLiteDatabase1.execSQL("DELETE FROM LAB6 WHERE ID='" + m_id.getText() + "'" );
                                        Toast.makeText(MainActivity.this, "Deleted", Toast.LENGTH_SHORT).show();
                                        alertDialogDelete.setNeutralButton("CLOSE", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) { }
                                        });
                                        alertDialogDelete.show().getWindow().setLayout(1250  , WindowManager.LayoutParams.WRAP_CONTENT);
                                        m_id.setText("");   m_name.setText(""); m_marks.setText("");
                                    }
                                }
                            }
                        });

                        alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MainActivity.this, "Delete Canceled!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } // out of if
                } // out of while

                if(!check) {
                    //Toast.makeText(MainActivity.this, "CHECK FAILED", Toast.LENGTH_SHORT).show();
                    alertDialog.setTitle(R.string.title_false);
                    m_id.setText("");   m_name.setText(""); m_marks.setText("");
                }

                alertDialog.setNeutralButton("CLOSE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) { }
                });
                alertDialog.show().getWindow().setLayout(1250  , WindowManager.LayoutParams.WRAP_CONTENT);
                cursor.close();
            }
        });
    }
}
