package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView m_username, m_password;
    EditText username, password;
    Button b_username, b_password, b_user_pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        m_username = (TextView)findViewById(R.id.textView2);
        m_password = (TextView)findViewById(R.id.textView3);
        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);
        b_username = (Button)findViewById(R.id.b_username);
        b_password = (Button)findViewById(R.id.b_password);
        b_user_pass = (Button)findViewById(R.id.b_user_pass);

        b_username.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { b_username.setText(username.getText().toString()); }
        });

        b_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { b_password.setText(password.getText().toString()); }
        });

        b_user_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String temp = getString(R.string.b_display, username.getText().toString(), password.getText().toString());
                b_user_pass.setText(temp);};
        });
    }
}
