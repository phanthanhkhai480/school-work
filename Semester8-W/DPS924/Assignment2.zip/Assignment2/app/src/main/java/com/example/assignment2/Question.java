package com.example.assignment2;

public class Question {
    private int mTextResId, mHint;
    private boolean mAnswerTrue, mUserHinted, mUserCheated, mAnswered;

    Question(int textResId, int hint, boolean answerTrue, boolean userHinted, boolean userCheated, boolean answered) {
        this.mTextResId = textResId;
        this.mHint = hint;
        this.mAnswerTrue = answerTrue;
        this.mUserHinted = userHinted;
        this.mUserCheated = userCheated;
        this.mAnswered = answered;
    }

    int getmTextResId() {   return mTextResId;  }

    public void setmTextResId(int mTextResId) {
        this.mTextResId = mTextResId;
    }

    boolean ismAnswerTrue() {
        return mAnswerTrue;
    }

    public void setmAnswerTrue(boolean mAnswerTrue) {
        this.mAnswerTrue = mAnswerTrue;
    }

    boolean ismUserCheated() {  return mUserCheated;    }

    public void setmUserCheated(boolean mUserCheated) {     this.mUserCheated = mUserCheated;   }

    public int getmHint() {     return mHint;   }

    public void setmHint(int mHint) {   this.mHint = mHint;     }

    public boolean ismAnswered() {  return mAnswered; }

    public void setmAnswered(boolean mAnswered) { this.mAnswered = mAnswered; }

    public boolean ismUserHinted() { return mUserHinted; }

    public void setmUserHinted(boolean mUserHinted) { this.mUserHinted = mUserHinted; }
}
