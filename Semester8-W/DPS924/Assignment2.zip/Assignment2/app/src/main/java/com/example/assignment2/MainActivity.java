package com.example.assignment2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "QuizActivity";
    private static final String KEY_INDEX = "index";
    private static final int REQUEST_CODE_CHEAT = 0;
    private static final int REQUEST_CODE_HINT = 1;
    private int mCurrentIndex = 0;

    private Question[] mQuestionBank = new Question[] {
            new Question(R.string.australia,                   R.string.australia_hint,
                    true, false,false,false),
            new Question(R.string.oceans,    R.string.oceans_hint,
                    true, false,false,false),
            new Question(R.string.mideast, R.string.mideast_hint,
                    false,false,false,false),
            new Question(R.string.africa,                   R.string.africa_hint,
                    false,false,false,false),
            new Question(R.string.americas,  R.string.americas_hint,
                    true, false,false,false),
            new Question(R.string.asia,  R.string.asia_hint,
                    true, false,false,false),
    };

    TextView mTotal_mark, mQuestion_completed, mQuestion;
    Button mCorrect, mIncorrect, mHint, mCheat, mPrevious, mNext;
    int score = 0, completed = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate(Bundle) called");
        setContentView(R.layout.activity_main);

        mTotal_mark = findViewById(R.id.total_mark);
        mQuestion_completed = findViewById(R.id.question_completed);
        mQuestion = findViewById(R.id.questions);
        mCorrect = findViewById(R.id.correct);
        mIncorrect = findViewById(R.id.incorrect);
        mHint = findViewById(R.id.hint);
        mCheat = findViewById(R.id.cheat);
        mPrevious = findViewById(R.id.previous);
        mNext = findViewById(R.id.next);

        if (savedInstanceState != null)
            mCurrentIndex = savedInstanceState.getInt(KEY_INDEX, 0);

        //set answer to true for the question
        mCorrect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { checkAnswer(true); }
        });

        //set answer to false for the question
        mIncorrect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { checkAnswer(false); }
        });

        //go check hint for next question
        mHint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Hint.class);
                intent.putExtra("hint", mQuestionBank[mCurrentIndex].getmHint());
                startActivityForResult(intent, REQUEST_CODE_HINT);
            }
        });

        mCheat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Cheat.class);
                intent.putExtra("cheat", mQuestionBank[mCurrentIndex].ismAnswerTrue());
                startActivityForResult(intent,REQUEST_CODE_CHEAT);
            }
        });

        //go to the previous question
        mPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentIndex = ((mCurrentIndex - 1) % mQuestionBank.length);
                if(mCurrentIndex < 0)
                    mCurrentIndex = mQuestionBank.length - 1;
                updateQuestion();
            }
        });

        //go to the next question
        mNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentIndex = (mCurrentIndex + 1) % mQuestionBank.length;
                updateQuestion();
            }
        });
        updateQuestion();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart() called");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume() called");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause() called");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop() called");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy() called");
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        Log.i(TAG, "onSaveInstanceState");
        savedInstanceState.putInt(KEY_INDEX, mCurrentIndex);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK)
            return;
        if (data == null)
            return;
        if (requestCode == REQUEST_CODE_HINT)
            mQuestionBank[mCurrentIndex].setmUserHinted(Hint.wasHintShown(data));
        if (requestCode == REQUEST_CODE_CHEAT)
            mQuestionBank[mCurrentIndex].setmUserCheated(Cheat.wasAnswerShown(data));

    }

    //update new questions when clicking Next or Previous
    private void updateQuestion() {
        int question = mQuestionBank[mCurrentIndex].getmTextResId();
        mQuestion.setText(question);
    }

    private void checkAnswer(boolean userPressedTrue) {
        String message = "";
        boolean answerIsTrue = mQuestionBank[mCurrentIndex].ismAnswerTrue();

        //if user used cheat
        if(mQuestionBank[mCurrentIndex].ismUserCheated())
            message = "Cheating is wrong!";
        //if question is already answer, toast to inform user
        else if(mQuestionBank[mCurrentIndex].ismAnswered())
            message = "Question Answered";
        //if the question isn't answered, proceed with the information
        else {
            mQuestionBank[mCurrentIndex].setmAnswered(true);

            //if user used hint
            if(mQuestionBank[mCurrentIndex].ismUserHinted()) {
                if(userPressedTrue == answerIsTrue) {
                    message = "+1 point";
                    score += 1;
                }
                else {
                    message = "-2 point";
                    score -= 2;
                }
                completed++;
            }
            //if user answer question normal
            else {
                if(userPressedTrue == answerIsTrue) {
                    message = "+2 point";
                    score += 2;
                }
                else {
                    message = "-1 point";
                    score -= 1;
                }
                completed++;
            }
            mTotal_mark.setText(String.valueOf(score));
            mQuestion_completed.setText(String.valueOf(completed));
            if(completed == mQuestionBank.length)
                message = "All Questions have been answered!";
        }
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }
}
