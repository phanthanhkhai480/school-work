package com.example.assignment2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Hint extends AppCompatActivity {
    TextView mHint;
    Button mShowHint, mExit;
    private boolean check = false;

    private static final String EXTRA_HINT_SHOWN =
            "com.bignerdranch.android.geoquiz.answer_shown";

    public static boolean wasHintShown(Intent result) {
        return result.getBooleanExtra(EXTRA_HINT_SHOWN, false);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hint2);

        mHint = (TextView) findViewById(R.id.hint);
        mShowHint = (Button) findViewById(R.id.show_hint);
        mExit = (Button) findViewById(R.id.exit);

        mShowHint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_1 = getIntent();
                int temp_1 = intent_1.getIntExtra("hint",0);
                if(temp_1 != 0) {
                    mHint.setText(temp_1);
                    check = true;
                }
                setHintShownResult(check);
            }
        });

        mExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { finish(); }
        });
    }

    private void setHintShownResult(boolean isHintShown) {
        Intent data = new Intent();
        data.putExtra(EXTRA_HINT_SHOWN, isHintShown);
        setResult(RESULT_OK, data);
    }
}
