package com.bignerdranch.android.geoquiz;

import android.content.Intent;
import android.os.Bundle;
import android.support.p003v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class QuizActivity extends AppCompatActivity {
    private static final String KEY_INDEX = "index";
    private static final int REQUEST_CODE_CHEAT = 0;
    private static final int REQUEST_CODE_HINT = 1;
    private static final String TAG = "QuizActivity";
    private Button mCheatButton;
    /* access modifiers changed from: private */
    public int mCurrentIndex;
    private Button mFalseButton;
    private Button mHintButton;
    private Button mNextButton;
    private Button mPrevButton;
    /* access modifiers changed from: private */
    public Question[] mQuestionBank;
    private TextView mQuestionTextView;
    private Button mTrueButton;
    int totalMarks = 0;

    public QuizActivity() {
        Question question = new Question(C0282R.string.question_australia, true, false, false, false, C0282R.string.hint_australia);
        Question question2 = new Question(C0282R.string.question_oceans, true, false, false, false, C0282R.string.hint_oceans);
        Question question3 = new Question(C0282R.string.question_mideast, false, false, false, false, C0282R.string.hint_mideast);
        Question question4 = new Question(C0282R.string.question_africa, false, false, false, false, C0282R.string.hint_africa);
        Question question5 = new Question(C0282R.string.question_americas, true, false, false, false, C0282R.string.hint_americas);
        Question question6 = new Question(C0282R.string.question_asia, true, false, false, false, C0282R.string.hint_asia);
        this.mQuestionBank = new Question[]{question, question2, question3, question4, question5, question6};
        this.mCurrentIndex = 0;
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate(Bundle) called");
        setContentView((int) C0282R.layout.activity_quiz);
        if (savedInstanceState != null) {
            this.mCurrentIndex = savedInstanceState.getInt(KEY_INDEX, 0);
        }
        this.mQuestionTextView = (TextView) findViewById(C0282R.C0284id.question_text_view);
        this.mTrueButton = (Button) findViewById(C0282R.C0284id.true_button);
        this.mTrueButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                QuizActivity.this.checkAnswer(true);
            }
        });
        this.mFalseButton = (Button) findViewById(C0282R.C0284id.false_button);
        this.mFalseButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                QuizActivity.this.checkAnswer(false);
            }
        });
        this.mNextButton = (Button) findViewById(C0282R.C0284id.next_button);
        this.mNextButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                QuizActivity quizActivity = QuizActivity.this;
                quizActivity.mCurrentIndex = (quizActivity.mCurrentIndex + 1) % QuizActivity.this.mQuestionBank.length;
                QuizActivity.this.updateQuestion();
            }
        });
        this.mPrevButton = (Button) findViewById(C0282R.C0284id.previous_button);
        this.mPrevButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                QuizActivity quizActivity = QuizActivity.this;
                quizActivity.mCurrentIndex = quizActivity.mCurrentIndex - 1;
                if (QuizActivity.this.mCurrentIndex == -1) {
                    QuizActivity quizActivity2 = QuizActivity.this;
                    quizActivity2.mCurrentIndex = quizActivity2.mQuestionBank.length - 1;
                }
                QuizActivity.this.updateQuestion();
            }
        });
        this.mCheatButton = (Button) findViewById(C0282R.C0284id.cheat_button);
        this.mCheatButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                QuizActivity.this.startActivityForResult(CheatActivity.newIntent(QuizActivity.this, QuizActivity.this.mQuestionBank[QuizActivity.this.mCurrentIndex].isAnswerTrue()), 0);
            }
        });
        this.mHintButton = (Button) findViewById(C0282R.C0284id.hint_button);
        this.mHintButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                QuizActivity.this.startActivityForResult(HintActivity.newIntent(QuizActivity.this, QuizActivity.this.mQuestionBank[QuizActivity.this.mCurrentIndex].getTextHintId()), 1);
            }
        });
        updateQuestion();
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == -1) {
            if (requestCode == 0) {
                if (data != null) {
                    this.mQuestionBank[this.mCurrentIndex].setUserCheated(CheatActivity.wasAnswerShown(data));
                } else {
                    return;
                }
            }
            if (requestCode == 1 && data != null) {
                this.mQuestionBank[this.mCurrentIndex].setHintGiven(HintActivity.wasHintShown(data));
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        Log.d(TAG, "onStart() called");
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume() called");
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause() called");
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        Log.i(TAG, "onSaveInstanceState");
        savedInstanceState.putInt(KEY_INDEX, this.mCurrentIndex);
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop() called");
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy() called");
    }

    /* access modifiers changed from: private */
    public void updateQuestion() {
        this.mQuestionTextView.setText(this.mQuestionBank[this.mCurrentIndex].getTextResId());
    }

    /* access modifiers changed from: private */
    public void checkAnswer(boolean userPressedTrue) {
        boolean answerIsTrue = this.mQuestionBank[this.mCurrentIndex].isAnswerTrue();
        if (this.mQuestionBank[this.mCurrentIndex].isComplete()) {
            Toast.makeText(this, "Question Completed!", 0).show();
        } else if (this.mQuestionBank[this.mCurrentIndex].didUserCheat()) {
            Toast.makeText(this, "Cheating is Wrong!", 0).show();
        } else {
            this.mQuestionBank[this.mCurrentIndex].setCompleted(true);
            TextView textView = (TextView) findViewById(C0282R.C0284id.questionsID);
            int temp = Integer.parseInt(textView.getText().toString()) + 1;
            StringBuilder sb = new StringBuilder();
            sb.append(BuildConfig.FLAVOR);
            sb.append(temp);
            textView.setText(sb.toString());
            if (userPressedTrue == answerIsTrue && this.mQuestionBank[this.mCurrentIndex].wasHintGiven()) {
                this.totalMarks++;
                Toast.makeText(this, "+1 Marks", 0).show();
            } else if (userPressedTrue == answerIsTrue && !this.mQuestionBank[this.mCurrentIndex].wasHintGiven()) {
                this.totalMarks += 2;
                Toast.makeText(this, "+2 Marks", 0).show();
            } else if (userPressedTrue != answerIsTrue && this.mQuestionBank[this.mCurrentIndex].wasHintGiven()) {
                this.totalMarks -= 2;
                Toast.makeText(this, "-2 Marks", 0).show();
            } else if (userPressedTrue != answerIsTrue && !this.mQuestionBank[this.mCurrentIndex].wasHintGiven()) {
                this.totalMarks--;
                Toast.makeText(this, "-1 Marks", 0).show();
            }
            TextView textView2 = (TextView) findViewById(C0282R.C0284id.marksID);
            StringBuilder sb2 = new StringBuilder();
            sb2.append(" ");
            sb2.append(this.totalMarks);
            textView2.setText(sb2.toString());
        }
    }
}
