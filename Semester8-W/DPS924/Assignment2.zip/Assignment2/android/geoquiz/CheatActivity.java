package com.bignerdranch.android.geoquiz;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.p003v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class CheatActivity extends AppCompatActivity {
    private static final String EXTRA_ANSWER_IS_TRUE = "com.bignerdranch.android.geoquiz.answer_is_true";
    private static final String EXTRA_ANSWER_SHOWN = "com.bignerdranch.android.geoquiz.answer_shown";
    /* access modifiers changed from: private */
    public boolean mAnswerIsTrue;
    /* access modifiers changed from: private */
    public TextView mAnswerTextView;
    private Button mShowAnswerButton;

    public static Intent newIntent(Context packageContext, boolean answerIsTrue) {
        Intent intent = new Intent(packageContext, CheatActivity.class);
        intent.putExtra(EXTRA_ANSWER_IS_TRUE, answerIsTrue);
        return intent;
    }

    public static boolean wasAnswerShown(Intent result) {
        return result.getBooleanExtra(EXTRA_ANSWER_SHOWN, false);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0282R.layout.activity_cheat);
        this.mAnswerIsTrue = getIntent().getBooleanExtra(EXTRA_ANSWER_IS_TRUE, false);
        this.mAnswerTextView = (TextView) findViewById(C0282R.C0284id.answer_text_view);
        this.mShowAnswerButton = (Button) findViewById(C0282R.C0284id.show_answer_button);
        this.mShowAnswerButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (CheatActivity.this.mAnswerIsTrue) {
                    CheatActivity.this.mAnswerTextView.setText(C0282R.string.true_button);
                } else {
                    CheatActivity.this.mAnswerTextView.setText(C0282R.string.false_button);
                }
                CheatActivity.this.setAnswerShownResult(true);
            }
        });
        ((Button) findViewById(C0282R.C0284id.exit_cheat_button)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                CheatActivity.this.finish();
            }
        });
    }

    /* access modifiers changed from: private */
    public void setAnswerShownResult(boolean isAnswerShown) {
        Intent data = new Intent();
        data.putExtra(EXTRA_ANSWER_SHOWN, isAnswerShown);
        setResult(-1, data);
    }
}
