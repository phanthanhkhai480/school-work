package com.bignerdranch.android.geoquiz;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.p003v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class HintActivity extends AppCompatActivity {
    private static final String EXTRA_ANSWER_IS_TRUE = "com.bignerdranch.android.geoquiz.answer_is_true";
    private static final String EXTRA_ANSWER_SHOWN = "com.bignerdranch.android.geoquiz.answer_shown";
    /* access modifiers changed from: private */
    public int mAnswerIsTrue;
    /* access modifiers changed from: private */
    public TextView mHintTextView;
    private Button mShowHintButton;

    public static Intent newIntent(Context packageContext, int answerIsTrue) {
        Intent intent = new Intent(packageContext, HintActivity.class);
        intent.putExtra(EXTRA_ANSWER_IS_TRUE, answerIsTrue);
        return intent;
    }

    public static boolean wasHintShown(Intent result) {
        return result.getBooleanExtra(EXTRA_ANSWER_SHOWN, false);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0282R.layout.activity_hint);
        this.mAnswerIsTrue = getIntent().getIntExtra(EXTRA_ANSWER_IS_TRUE, 0);
        this.mHintTextView = (TextView) findViewById(C0282R.C0284id.hint_text_view);
        this.mShowHintButton = (Button) findViewById(C0282R.C0284id.show_hint_button);
        this.mShowHintButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                HintActivity.this.mHintTextView.setText(HintActivity.this.mAnswerIsTrue);
                HintActivity.this.setAnswerShownResult(true);
            }
        });
        ((Button) findViewById(C0282R.C0284id.exit_hint_button)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                HintActivity.this.finish();
            }
        });
    }

    /* access modifiers changed from: private */
    public void setAnswerShownResult(boolean isAnswerShown) {
        Intent data = new Intent();
        data.putExtra(EXTRA_ANSWER_SHOWN, isAnswerShown);
        setResult(-1, data);
    }
}
