package com.example.lab3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    String[] number = new String[99];
    String[] letter = new String[26];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ListView layout1 = (ListView) findViewById(R.id.layout1);
        GridView layout2 = (GridView) findViewById(R.id.layout2);

        for(int a = 0; a < letter.length; a++)
            letter[a] = (char)(65+a) + "";
        ArrayAdapter<String> adapter_1 = new ArrayAdapter<>(this, R.layout.display_layout1, letter);
        layout1.setAdapter(adapter_1);


        for(int b = 0; b < number.length; b++)
            number[b] = "" + (b+1)*5;
        ArrayAdapter<String> adapter_2 = new ArrayAdapter<>(this, R.layout.display_layout, number);
        layout2.setAdapter(adapter_2);



    }
}
